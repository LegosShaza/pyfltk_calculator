from fltk import *
import math

WINDOW_W, WINDOW_H = 420, 700

ROMAN_MAP = [
    ("M", 1000), ("CM", 900), ("D", 500), ("CD", 400),
    ("C", 100), ("XC", 90), ("L", 50), ("XL", 40),
    ("X", 10), ("IX", 9), ("V", 5), ("IV", 4), ("I", 1)
]

def to_roman(num):
    result = ""
    for sym, val in ROMAN_MAP:
        while num >= val:
            result += sym
            num -= val
    return result

def from_roman(s):
    s = s.upper()
    i = 0
    num = 0
    for sym, val in ROMAN_MAP:
        while s[i:i+len(sym)] == sym:
            num += val
            i += len(sym)
            if i >= len(s):
                return num
    return num

class CalculatorUI:
    def __init__(self):
        self.win = Fl_Window(WINDOW_W, WINDOW_H, "PyFLTK Kalkulačka+")
        self.win.begin()

        self.input = Fl_Input(20, 20, 380, 40, "")
        self.input.textsize(20)

        self.result_display = Fl_Output(20, 70, 380, 40, "")
        self.result_display.textsize(18)

        self.history = Fl_Hold_Browser(20, 120, 380, 200)

        self.mode_rad = True
        self.create_buttons()

        self.win.end()
        self.win.show()

    def create_buttons(self):
        buttons = [
            ["7", "8", "9", "/", "sin"],
            ["4", "5", "6", "*", "cos"],
            ["1", "2", "3", "-", "tan"],
            ["0", ".", "=", "+", "log"],
            ["C", "(", ")", "←", "%"],
            ["bin", "oct", "hex", "base", "ROM"],
            ["rad/deg", "exp", "^", "√", "π"]
        ]
        w, h = 70, 40
        x0, y0 = 20, 340
        gap = 10

        for r, row in enumerate(buttons):
            for c, label in enumerate(row):
                btn = Fl_Button(x0 + c*(w+gap), y0 + r*(h+gap), w, h, label)
                btn.callback(self.on_button)

    def on_button(self, widget):
        label = widget.label()
        if label == "C":
            self.clear()
            return
        if label == "←":
            self.backspace()
            return
        if label == "=":
            self.calculate()
            return
        if label == "rad/deg":
            self.toggle_mode()
            return
        if label in ("bin", "oct", "hex", "base", "ROM"):
            self.convert(label)
            return

        pos = self.input.insert_position()
        text = self.input.value()
        new_text = text[:pos] + label + text[pos:]
        self.input.value(new_text)
        self.input.insert_position(pos + len(label))

    def clear(self):
        self.input.value("")
        self.result_display.value("")

    def backspace(self):
        text = self.input.value()
        pos = self.input.insert_position()
        if pos > 0:
            new_text = text[:pos-1] + text[pos:]
            self.input.value(new_text)
            self.input.insert_position(pos-1)

    def toggle_mode(self):
        self.mode_rad = not self.mode_rad
        mode_str = "Radiány" if self.mode_rad else "Stupně"
        fl_message(f"Přepnuto na {mode_str}")

    def convert(self, mode):
        val = self.result_display.value() or self.input.value()
        if not val:
            fl_message("Žádné číslo k převodu!")
            return

        try:
            if mode == "bin":
                result = bin(int(float(val)))[2:]
            elif mode == "oct":
                result = oct(int(float(val)))[2:]
            elif mode == "hex":
                result = hex(int(float(val)))[2:].upper()
            elif mode == "ROM":
                result = to_roman(int(float(val)))
            elif mode == "base":
                base = int(fl_input("Zadej základ soustavy (2–36):") or "10")
                if not 2 <= base <= 36:
                    fl_message("Základ musí být 2–36")
                    return
                result = self.to_base(int(float(val)), base)
            else:
                result = val
            self.result_display.value(result)
        except Exception as e:
            fl_message(f"Chyba převodu:\n{e}")

    def to_base(self, n, base):
        digits = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        if n == 0:
            return "0"
        res = ""
        while n:
            res = digits[n % base] + res
            n //= base
        return res

    def calculate(self):
        expr = self.input.value().strip()
        if not expr:
            return

        expr = expr.replace("^", "**").replace("√", "sqrt")
        expr = expr.replace("%", "/100")

        def sin(x): return math.sin(math.radians(x)) if not self.mode_rad else math.sin(x)
        def cos(x): return math.cos(math.radians(x)) if not self.mode_rad else math.cos(x)
        def tan(x): return math.tan(math.radians(x)) if not self.mode_rad else math.tan(x)

        try:
            result = eval(expr, {"__builtins__": None}, {
                "sin": sin, "cos": cos, "tan": tan,
                "log": math.log, "sqrt": math.sqrt, "pi": math.pi, "e": math.e, "exp": math.exp
            })
            self.result_display.value(str(result))
            self.history.add(f"{expr} = {result}")
        except Exception as e:
            fl_message(f"Chyba: {e}")

    def run(self):
        Fl.run()

if __name__ == "__main__":
    app = CalculatorUI()
    app.run()
